import app from './App'

new app().startApp()
