require('dotenv/config')
import * as express from "express";
import { createConnection } from 'typeorm'
import "reflect-metadata"
import { deflate } from "zlib"

export default class App {
    private port = process.env.PORT
    public app: express.Application

    public constructor () {
        this.app = express.default();
    }

    public startApp () {
        createConnection().then(async connection => {})
        this.app.listen(this.port, () => { console.log(`Server running in port: ${this.port}`) })
    }
}